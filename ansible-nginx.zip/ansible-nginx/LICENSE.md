Copyright (C) 2013 AnsibleWorks, Inc.

This work is licensed under the Creative Commons Attribution 3.0 Unported License. 
To view a copy of this license, visit http://creativecommons.org/licenses/by/3.0/deed.en_US. 
