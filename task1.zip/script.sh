#!/bin/bash

echo myfirstpage.com  127.0.0.1 >> /etc/hosts ; echo mysecondpage.com 127.0.0.1 >> /etc/hosts; echo mythirdpage.com  127.0.0.1 >> /etc/hosts 
cp /home/admin/mypages.com.conf /etc/nginx/conf.d/
cp /home/admin/*.html   /var/www/html
 
sudo chown -R www-data:www-data /var/www/html/ 
sudo chmod 755 /var/www/html

service nginx start
